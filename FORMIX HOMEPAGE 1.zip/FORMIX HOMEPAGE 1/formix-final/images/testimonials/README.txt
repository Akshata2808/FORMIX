Optional photos for testimonials 4 and 5 (square, about 360x360): anita-verma.jpg, karan-malhotra.jpg
They automatically replace the illustrated avatars.
