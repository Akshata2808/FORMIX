Optional real product photos (they automatically cover the illustrations):
amplifier-ic.jpg, microcontroller-ic.jpg, mosfet.jpg, regulator-ic.jpg
